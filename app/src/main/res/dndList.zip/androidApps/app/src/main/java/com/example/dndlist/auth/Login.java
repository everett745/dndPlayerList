package com.example.dndlist.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.dndlist.R;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}